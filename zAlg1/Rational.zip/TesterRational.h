#ifndef _LARGERATIONAL_TEST_h_included_
#define _LARGERATIONAL_TEST_h_included_

#include "LargeRational.h"
#include "Large.h"

using namespace std;

class TesterRational{
	private:
		long base;
		long in_base;

	public:
		TesterRational(){
			base = 100;
			in_base = 16;
		}
		
		//uruchom seri� test�w
		void run();

		//funkcje testuj�ce Large
		// 1 funkcja testuje 1 operacj� na r�nych przypadkach
		void test_set();
		void test_divide();
		void test_substract();
		void test_GDC();
		void test_add();
		void test_mul();
};

#endif